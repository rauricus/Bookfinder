# LibVision > 2024-10-11 4:23pm
https://universe.roboflow.com/libvision/libvision

Provided by a Roboflow user
License: CC BY 4.0

